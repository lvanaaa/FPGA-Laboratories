
module LCD5110 (
    input  wire clk,
    output reg lcd_rst = 0,
    output reg lcd_ce  = 1,
    output reg lcd_dc  = 0,
    output reg lcd_din = 0,
    output reg lcd_clk = 0
);

    // ==========================================
    // NOKIA 5110 - PCD8544
    // FPGA CLOCK: 50 MHz
    // DISPLAY: 84 x 48 pixels
    //
    // RAND 1: WALID
    // RAND 2: LUANA
    // ==========================================

    // ==========================================
    // 1. INITIALIZARE LCD
    // ==========================================

    function [7:0] init_byte;
        input [2:0] n;
        begin
            case (n)
                0: init_byte = 8'h21;
                1: init_byte = 8'hB8;
                2: init_byte = 8'h04;
                3: init_byte = 8'h14;
                4: init_byte = 8'h20;
                5: init_byte = 8'h0C;
                6: init_byte = 8'h80;
                7: init_byte = 8'h40;
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    // ==========================================
    // 2. FONT 5x7 - WALID / LUANA
    // ==========================================

    // Pozitiile 0..83   = primul rand
    // Pozitiile 84..167 = al doilea rand

    function [7:0] text_byte;
        input [9:0] n;
        begin
            case (n)

                // ==========================
                // RANDUL 1: WALID
                // ==========================

                // W
                0: text_byte = 8'h7F;
                1: text_byte = 8'h40;
                2: text_byte = 8'h38;
                3: text_byte = 8'h40;
                4: text_byte = 8'h7F;

                // A
                6: text_byte = 8'h7E;
                7: text_byte = 8'h11;
                8: text_byte = 8'h11;
                9: text_byte = 8'h11;
                10: text_byte = 8'h7E;

                // L
                12: text_byte = 8'h7F;
                13: text_byte = 8'h40;
                14: text_byte = 8'h40;
                15: text_byte = 8'h40;
                16: text_byte = 8'h40;

                // I
                18: text_byte = 8'h41;
                19: text_byte = 8'h41;
                20: text_byte = 8'h7F;
                21: text_byte = 8'h41;
                22: text_byte = 8'h41;

                // D
                24: text_byte = 8'h7F;
                25: text_byte = 8'h41;
                26: text_byte = 8'h41;
                27: text_byte = 8'h22;
                28: text_byte = 8'h1C;

                // ==========================
                // RANDUL 2: LUANA
                // ==========================

                // L
                84: text_byte = 8'h7F;
                85: text_byte = 8'h40;
                86: text_byte = 8'h40;
                87: text_byte = 8'h40;
                88: text_byte = 8'h40;

                // U
                90: text_byte = 8'h3F;
                91: text_byte = 8'h40;
                92: text_byte = 8'h40;
                93: text_byte = 8'h40;
                94: text_byte = 8'h3F;

                // A
                96: text_byte = 8'h7E;
                97: text_byte = 8'h11;
                98: text_byte = 8'h11;
                99: text_byte = 8'h11;
                100: text_byte = 8'h7E;

                // N
                102: text_byte = 8'h7F;
                103: text_byte = 8'h02;
                104: text_byte = 8'h0C;
                105: text_byte = 8'h10;
                106: text_byte = 8'h7F;

                // A
                108: text_byte = 8'h7E;
                109: text_byte = 8'h11;
                110: text_byte = 8'h11;
                111: text_byte = 8'h11;
                112: text_byte = 8'h7E;

                // Spatii si restul ecranului
                default: text_byte = 8'h00;

            endcase
        end
    endfunction

    // ==========================================
    // 3. FAZELE DE TRANSMISIE
    // ==========================================

    // 0 = initializare
    // 1 = stergere ecran
    // 2 = pozitionare cursor
    // 3 = afisare WALID si LUANA

    reg [1:0] phase = 0;
    reg [9:0] pos = 0;

    wire [7:0] tx_byte =
        (phase == 0) ? init_byte(pos[2:0]) :
        (phase == 1) ? 8'h00 :
        (phase == 2) ?
            ((pos == 0) ? 8'h80 : 8'h40) :
        text_byte(pos);

    // ==========================================
    // 4. STATE MACHINE
    // ==========================================

    localparam RESET_LOW  = 4'd0;
    localparam RESET_HIGH = 4'd1;
    localparam LOAD       = 4'd2;
    localparam CLOCK_UP   = 4'd3;
    localparam CLOCK_DOWN = 4'd4;
    localparam BYTE_END   = 4'd5;
    localparam ADVANCE    = 4'd6;
    localparam DONE       = 4'd7;

    reg [3:0] state = RESET_LOW;

    reg [21:0] timer = 0;
    reg [5:0] spi_div = 0;
    reg [7:0] shift_byte = 0;
    reg [2:0] bit_index = 0;

    always @(posedge clk) begin

        case (state)

            // ==========================
            // RESET LCD
            // ==========================

            RESET_LOW: begin
                lcd_rst <= 0;
                lcd_ce <= 1;
                lcd_clk <= 0;

                if (timer == 22'd999999) begin
                    timer <= 0;
                    lcd_rst <= 1;
                    state <= RESET_HIGH;
                end
                else
                    timer <= timer + 1'b1;
            end

            RESET_HIGH: begin
                if (timer == 22'd2499999) begin
                    timer <= 0;
                    state <= LOAD;
                end
                else
                    timer <= timer + 1'b1;
            end

            // ==========================
            // INCARCARE BYTE
            // ==========================

            LOAD: begin
                lcd_ce <= 0;

                // 0 = comanda
                // 1 = date
                lcd_dc <= (phase == 1 ||
                           phase == 3);

                lcd_clk <= 0;
                lcd_din <= tx_byte[7];

                shift_byte <= tx_byte;
                bit_index <= 7;
                spi_div <= 0;

                state <= CLOCK_UP;
            end

            // ==========================
            // SPI CLOCK HIGH
            // ==========================

            CLOCK_UP: begin
                if (spi_div == 6'd49) begin
                    spi_div <= 0;
                    lcd_clk <= 1;
                    state <= CLOCK_DOWN;
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            // ==========================
            // SPI CLOCK LOW
            // ==========================

            CLOCK_DOWN: begin
                if (spi_div == 6'd49) begin
                    spi_div <= 0;
                    lcd_clk <= 0;

                    if (bit_index == 0)
                        state <= BYTE_END;
                    else begin
                        bit_index <= bit_index - 1'b1;
                        lcd_din <= shift_byte[6];

                        shift_byte <= {
                            shift_byte[6:0], 1'b0
                        };

                        state <= CLOCK_UP;
                    end
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            // ==========================
            // SFARSIT BYTE
            // ==========================

            BYTE_END: begin
                lcd_ce <= 1;
                state <= ADVANCE;
            end

            // ==========================
            // AVANSARE
            // ==========================

            ADVANCE: begin

                // Am transmis ambele randuri
                if (phase == 3 && pos == 10'd167) begin
                    state <= DONE;
                end
                else begin
                    state <= LOAD;

                    // Initializare terminata
                    if (phase == 0 && pos == 10'd7) begin
                        phase <= 1;
                        pos <= 0;
                    end

                    // Ecran sters (504 bytes)
                    else if (phase == 1 &&
                             pos == 10'd503) begin
                        phase <= 2;
                        pos <= 0;
                    end

                    // Cursor la X=0, Y=0
                    else if (phase == 2 &&
                             pos == 10'd1) begin
                        phase <= 3;
                        pos <= 0;
                    end

                    else begin
                        pos <= pos + 1'b1;
                    end
                end
            end

            // ==========================
            // GATA
            // ==========================

            DONE: begin
                lcd_ce <= 1;
                lcd_clk <= 0;
            end

            default: begin
                state <= RESET_LOW;
            end

        endcase
    end

endmodule
